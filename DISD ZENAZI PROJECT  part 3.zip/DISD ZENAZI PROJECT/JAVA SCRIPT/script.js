document.addEventListener("DOMContentLoaded", function () {

    

    const tabContent = document.getElementById("tab-content");
    const tabButtons = document.querySelectorAll(".tab-btn");

    if (tabContent && tabButtons.length > 0) {

        tabButtons.forEach(button => {

            button.addEventListener("click", function () {

                tabButtons.forEach(btn =>
                    btn.classList.remove("active")
                );

                this.classList.add("active");

                const tab = this.dataset.tab;

                switch (tab) {

                    case "flatbed":
                        tabContent.innerHTML = `
                            <h3>Flatbed Truck</h3>
                            <p>Ideal for transporting machinery, steel structures and oversized cargo.</p>
                            <p><strong>Rate:</strong> R850/hour</p>
                        `;
                        break;

                    case "dump":
                        tabContent.innerHTML = `
                            <h3>Dump Truck</h3>
                            <p>Used for fast unloading of sand, rubble, gravel and construction waste.</p>
                            <p><strong>Rate:</strong> R650/hour</p>
                        `;
                        break;

                    case "backhoe":
                        tabContent.innerHTML = `
                            <h3>Backhoe Loader</h3>
                            <p>Perfect for excavation, trenching, loading and construction projects.</p>
                            <p><strong>Rate:</strong> R950/hour</p>
                        `;
                        break;

                    case "tipper":
                        tabContent.innerHTML = `
                            <h3>Tipper Truck</h3>
                            <p>Suitable for transporting aggregates, gravel, sand and bulk loads.</p>
                            <p><strong>Rate:</strong> R750/hour</p>
                        `;
                        break;

                    case "diesel":
                        tabContent.innerHTML = `
                            <h3>Diesel Supply</h3>
                            <p>We provide affordable diesel supply services to our customers.</p>
                            <p><strong>Rate:</strong> Negotiable upon request.</p>
                        `;
                        break;

                    case "catering":
                        tabContent.innerHTML = `
                            <h3>Catering Services</h3>
                            <p>We provide catering services supported by our own water products.</p>
                            <p><strong>Rate:</strong> Negotiable upon request.</p>
                        `;
                        break;

                    default:
                        tabContent.innerHTML = `
                            <p>Select a service above to view details.</p>
                        `;
                }
            });
        });
    }


    

    const modal = document.getElementById("fleet-modal");
    const modalImg = document.getElementById("modal-img");
    const caption = document.getElementById("caption");
    const fleetItems = document.querySelectorAll(".fleet-item");
    const closeBtn = document.querySelector(".close");

    if (modal && modalImg && closeBtn) {

        fleetItems.forEach(img => {

            img.addEventListener("click", function () {

                modal.style.display = "block";
                modalImg.src = this.src;

                if (caption) {
                    caption.textContent = this.alt;
                }
            });
        });

        closeBtn.addEventListener("click", function () {
            modal.style.display = "none";
        });

        window.addEventListener("click", function (e) {

            if (e.target === modal) {
                modal.style.display = "none";
            }
        });

        document.addEventListener("keydown", function (e) {

            if (e.key === "Escape") {
                modal.style.display = "none";
            }
        });
    }


    

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {

        anchor.addEventListener("click", function (e) {

            const href = this.getAttribute("href");

            if (href && href.length > 1) {

                const target = document.querySelector(href);

                if (target) {

                    e.preventDefault();

                    target.scrollIntoView({
                        behavior: "smooth"
                    });
                }
            }
        });
    });


    

    let zoomLevel = 100;

    const zoomContainer = document.createElement("div");

    zoomContainer.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        display: flex;
        gap: 10px;
        z-index: 99999;
    `;


    // ZOOM IN BUTTON
    const zoomIn = document.createElement("button");

    zoomIn.innerHTML = "+";

    zoomIn.setAttribute("style", `
        width: 45px !important;
        height: 45px !important;
        background-color: #00BFFF !important;
        color: white !important;
        border: none !important;
        border-radius: 50% !important;
        font-size: 28px !important;
        font-weight: bold !important;
        cursor: pointer !important;
        padding: 0 !important;
        outline: none !important;
        box-shadow: none !important;
    `);

    zoomIn.addEventListener("click", function () {

        if (zoomLevel < 150) {

            zoomLevel += 10;

            document.documentElement.style.zoom =
                zoomLevel + "%";
        }
    });


    // ZOOM OUT BUTTON
    const zoomOut = document.createElement("button");

    zoomOut.innerHTML = "−";

    zoomOut.setAttribute("style", `
        width: 45px !important;
        height: 45px !important;
        background-color: #00BFFF !important;
        color: white !important;
        border: none !important;
        border-radius: 50% !important;
        font-size: 28px !important;
        font-weight: bold !important;
        cursor: pointer !important;
        padding: 0 !important;
        outline: none !important;
        box-shadow: none !important;
    `);

    zoomOut.addEventListener("click", function () {

        if (zoomLevel > 70) {

            zoomLevel -= 10;

            document.documentElement.style.zoom =
                zoomLevel + "%";
        }
    });


    // ADD ZOOM BUTTONS TO WEBSITE
    zoomContainer.appendChild(zoomIn);
    zoomContainer.appendChild(zoomOut);

    document.body.appendChild(zoomContainer);


    

    const enquiryForm = document.getElementById("contact-form");
    const responseMessage = document.getElementById("form-response");

    if (enquiryForm && responseMessage) {

        enquiryForm.addEventListener("submit", function (e) {

            e.preventDefault();

            const nameField = document.getElementById("name");

            const customerName = nameField.value.trim();

            responseMessage.innerHTML = `
                <strong>Thank You, ${customerName}!</strong><br>
                Your enquiry has been submitted successfully.<br>
                Zenazi Supply & Transport appreciates your interest.<br>
                Our team will get back to you soon.
            `;

            responseMessage.style.display = "block";

            enquiryForm.reset();

            responseMessage.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        });
    }


    

    console.log("Zenazi Supply & Transport JavaScript loaded successfully!");

});
